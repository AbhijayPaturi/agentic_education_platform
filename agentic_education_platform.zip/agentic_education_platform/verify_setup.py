#!/usr/bin/env python3
"""
Setup Verification Script
=========================
Verifies that the agentic educational system is properly configured.

Run this script before using the application to ensure all dependencies
are installed and configuration is correct.
"""

import sys
from pathlib import Path


def print_section(title: str):
    """Print a formatted section header."""
    print(f"\n{'='*60}")
    print(f" {title}")
    print(f"{'='*60}\n")


def check_python_version():
    """Verify Python version is 3.10 or higher."""
    print_section("Checking Python Version")
    version = sys.version_info
    print(f"Python version: {version.major}.{version.minor}.{version.micro}")
    
    if version.major >= 3 and version.minor >= 10:
        print("✅ Python version is compatible")
        return True
    else:
        print("❌ Python 3.10 or higher is required")
        return False


def check_dependencies():
    """Check if required packages are installed."""
    print_section("Checking Dependencies")
    
    required = {
        'crewai': 'CrewAI framework',
        'openai': 'OpenAI API client',
        'dotenv': 'Environment variable management',
    }
    
    all_installed = True
    
    for package, description in required.items():
        try:
            if package == 'dotenv':
                __import__('dotenv')
            else:
                __import__(package)
            print(f"✅ {description} ({package})")
        except ImportError:
            print(f"❌ {description} ({package}) - NOT INSTALLED")
            all_installed = False
    
    if not all_installed:
        print("\n💡 Install missing packages with:")
        print("   pip install -r requirements.txt")
    
    return all_installed


def check_configuration():
    """Check if configuration is properly set up."""
    print_section("Checking Configuration")
    
    env_file = Path(__file__).parent / '.env'
    
    if not env_file.exists():
        print("❌ .env file not found")
        print("\n💡 Create .env file with:")
        print("   OPENAI_API_KEY=your_actual_api_key_here")
        return False
    
    print("✅ .env file exists")
    
    # Try to load configuration
    try:
        from dotenv import load_dotenv
        import os
        
        load_dotenv(dotenv_path=env_file)
        api_key = os.getenv('OPENAI_API_KEY')
        
        if not api_key or api_key == 'your_openai_api_key_here':
            print("⚠️  OPENAI_API_KEY not set or using placeholder value")
            print("\n💡 Edit .env and add your actual OpenAI API key")
            return False
        
        if api_key.startswith('sk-'):
            print("✅ OPENAI_API_KEY is configured")
            return True
        else:
            print("⚠️  OPENAI_API_KEY format looks incorrect (should start with 'sk-')")
            return False
            
    except Exception as e:
        print(f"❌ Error loading configuration: {e}")
        return False


def check_file_structure():
    """Verify all required files exist."""
    print_section("Checking File Structure")
    
    root = Path(__file__).parent
    
    required_files = [
        'agents/agents.py',
        'agents/tasks.py',
        'app/main.py',
        'config/config.py',
        'tools/video_generation_tool.py',
        'tests/test_tools.py',
        'tests/test_crews.py',
    ]
    
    all_exist = True
    
    for file_path in required_files:
        full_path = root / file_path
        if full_path.exists():
            print(f"✅ {file_path}")
        else:
            print(f"❌ {file_path} - NOT FOUND")
            all_exist = False
    
    return all_exist


def check_output_directory():
    """Verify output directory can be created."""
    print_section("Checking Output Directory")
    
    output_dir = Path(__file__).parent / 'output'
    
    try:
        output_dir.mkdir(exist_ok=True)
        print(f"✅ Output directory ready: {output_dir}")
        return True
    except Exception as e:
        print(f"❌ Cannot create output directory: {e}")
        return False


def run_import_test():
    """Test importing main modules."""
    print_section("Testing Module Imports")
    
    modules = [
        ('config.config', 'Configuration module'),
        ('agents.agents', 'Agents module'),
        ('agents.tasks', 'Tasks module'),
        ('tools.video_generation_tool', 'Custom tools'),
    ]
    
    all_imported = True
    
    for module_name, description in modules:
        try:
            __import__(module_name)
            print(f"✅ {description} ({module_name})")
        except Exception as e:
            print(f"❌ {description} ({module_name}) - {e}")
            all_imported = False
    
    return all_imported


def main():
    """Run all verification checks."""
    print("\n" + "="*60)
    print(" Agentic Educational System - Setup Verification")
    print("="*60)
    
    checks = [
        check_python_version(),
        check_dependencies(),
        check_file_structure(),
        check_configuration(),
        check_output_directory(),
        run_import_test(),
    ]
    
    print_section("Verification Summary")
    
    if all(checks):
        print("✅ All checks passed! System is ready to use.")
        print("\n🚀 Next steps:")
        print("   1. Run: python app/main.py")
        print("   2. Follow the prompts to create your curriculum")
        print("   3. Review generated content in output/ directory")
        print("\n📚 For more information:")
        print("   • README.md - Complete documentation")
        print("   • QUICKSTART.md - Quick start guide")
        print("   • ARCHITECTURE.md - Technical details")
        return 0
    else:
        print("❌ Some checks failed. Please fix the issues above.")
        print("\n💡 Common solutions:")
        print("   • Install dependencies: pip install -r requirements.txt")
        print("   • Create .env file with your OpenAI API key")
        print("   • Ensure Python 3.10+ is installed")
        return 1


if __name__ == "__main__":
    sys.exit(main())
