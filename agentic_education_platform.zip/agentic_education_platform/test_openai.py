#!/usr/bin/env python3
"""Verify OpenAI credentials and model access without generating content.

Run from the project root with the project environment activated:

    python test_openai.py

The check retrieves model metadata, which verifies authentication and model
access without sending learner data or using completion tokens.
"""

import os
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

PROJECT_ROOT = Path(__file__).resolve().parent


def main() -> int:
    """Return zero when credentials and configured model access are valid."""
    load_dotenv(PROJECT_ROOT / ".env")
    api_key = os.getenv("OPENAI_API_KEY")
    model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

    if not api_key:
        print("OPENAI_API_KEY is not set. Copy .env.example to .env and add your key.")
        return 1

    try:
        model_info = OpenAI(api_key=api_key).models.retrieve(model)
    except Exception as exc:
        print(f"OpenAI connectivity check failed: {type(exc).__name__}: {exc}")
        return 1

    print(f"OpenAI connection successful. Configured model is accessible: {model_info.id}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
