# Agentic Educational System

A production-grade, hierarchical agentic system that creates personalized month-long learning curricula using CrewAI and OpenAI's GPT-4.

## 🎯 Project Overview

This system demonstrates advanced agentic architecture by orchestrating multiple specialized AI agents to create comprehensive educational content based on a user's career goals. The system generates:

- **Personalized Learning Curriculum**: Month-long topic breakdown aligned with career objectives
- **Detailed Lesson Plans**: Structured lessons with clear objectives and progressions
- **Presentation Slides**: Markdown-formatted slides ready for conversion
- **Video Resources**: Curated suggestions for educational videos
- **Assessment Quizzes**: 5-question quizzes with answer keys for each topic

## 🏗️ Architecture Highlights

### Hierarchical Crew Design

The system employs a two-level crew structure that demonstrates scalability and separation of concerns:

1. **CurriculumCrew** (Strategic Level)
   - **Principal Agent**: Analyzes career goals and designs the overall learning path
   - Outputs: List of topics with rationale and time allocation
   - Single high-level decision-making agent

2. **ContentGenerationCrew** (Tactical Level)
   - **Teacher Agent**: Creates detailed lesson plans
   - **Slides Agent**: Generates presentation materials
   - **Video Agent**: Suggests relevant video resources (using custom tool)
   - **Test Agent**: Designs assessments to validate learning
   - Dynamically invoked once per approved topic

### Key Design Patterns

- **Human-in-the-Loop (HITL)**: User validation gate after curriculum proposal
- **Context Chaining**: Tasks receive output from predecessor tasks as context
- **Custom LLM-Powered Tools**: Video search tool leverages LLM's internal knowledge
- **Dynamic Workflow Generation**: Content crews instantiated per topic
- **Structured Output Management**: Organized file hierarchy for generated content

## 🚀 Getting Started

### Prerequisites

- Python 3.10 or higher
- OpenAI API key
- pip or poetry for dependency management

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd agentic_education_platform
   ```

2. **Create a virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure environment**
   ```bash
   cp .env.example .env
   ```
   
   Edit `.env` and add your OpenAI API key:
   ```
   OPENAI_API_KEY=your_actual_openai_api_key_here
   ```

### Running the Application

```bash
python app/main.py
```

Follow the interactive prompts:
1. Enter your name
2. Describe your career goal
3. Review the proposed curriculum
4. Approve or reject the curriculum
5. Wait for content generation (this may take several minutes)
6. Review generated content in the `output/` directory

## 📁 Project Structure

```
agentic_education_platform/
├── .env.example              # Environment variable template
├── README.md                 # This file
├── requirements.txt          # Production dependencies
├── requirements-devel.txt    # Development dependencies (testing, linting)
│
├── config/
│   ├── __init__.py
│   └── config.py            # Configuration management with python-dotenv
│
├── agents/
│   ├── __init__.py
│   ├── agents.py            # Agent definitions (Principal, Teacher, Slides, Video, Test)
│   └── tasks.py             # Task definitions with context chaining
│
├── tools/
│   ├── __init__.py
│   └── video_generation_tool.py  # Custom LLM-powered video search tool
│
├── app/
│   ├── __init__.py
│   └── main.py              # Application entry point and orchestration
│
├── tests/
│   ├── __init__.py
│   ├── test_tools.py        # Unit tests for custom tools
│   └── test_crews.py        # Integration tests with mocked API calls
│
└── output/                  # Generated educational content (created at runtime)
    └── [TOPIC_NAME]/
        └── complete_content.md
```

## 🧪 Testing

The project includes a comprehensive test suite demonstrating production-grade testing practices:

### Run all tests
```bash
pytest tests/ -v
```

### Run specific test files
```bash
pytest tests/test_tools.py -v
pytest tests/test_crews.py -v
```

### Run with coverage
```bash
pytest tests/ --cov=agents --cov=tools --cov=app --cov-report=html
```

### Testing Approach

- **Unit Tests**: Individual components (tools, parsers)
- **Integration Tests**: Crew orchestration with mocked API calls
- **Mock-Based Testing**: No actual OpenAI API calls during tests
- **Fixtures**: Reusable test data for consistency

## 🔧 Development Dependencies

Install development dependencies for testing and code quality:

```bash
pip install -r requirements-devel.txt
```

This includes:
- `pytest`: Testing framework
- `pytest-cov`: Coverage reporting
- `pytest-mock`: Advanced mocking capabilities
- `black`: Code formatting
- `flake8`: Linting
- `mypy`: Type checking

## 📚 Key Components Explained

### Agents (agents/agents.py)

Each agent has a specialized role, detailed backstory, and specific goals:

- **PrincipalAgent**: Curriculum designer with 30+ years expertise
- **TeacherAgent**: Master educator who breaks down complex topics
- **SlidesAgent**: Instructional designer specializing in presentations
- **VideoAgent**: Digital content curator (uses custom tool)
- **TestAgent**: Assessment specialist understanding Bloom's Taxonomy

### Tasks (agents/tasks.py)

Tasks define the work units with explicit dependencies:

- `topic_identification_task`: Generates curriculum (no dependencies)
- `lesson_planning_task`: Creates detailed lessons (foundation for others)
- `slides_creation_task`: Generates slides (depends on lesson plan)
- `video_generation_task`: Suggests videos (depends on lesson plan)
- `quiz_creation_task`: Creates assessments (depends on slides)

### Custom Tools (tools/video_generation_tool.py)

Since external APIs are not permitted, the `HypotheticalVideoSearchTool` demonstrates:

- Using LLM's internal knowledge to simulate external data sources
- Proper documentation of tool limitations
- Transparent communication about hypothetical nature of outputs
- Professional handling of API constraints

### Configuration (config/config.py)

- Loads environment variables securely
- Validates configuration at startup
- Provides helper functions for output path management
- Centralizes all configuration parameters

## 🎓 Usage Examples

### Example 1: Transitioning to Data Science

**Input**: "Transition from software development to data science"

**Generated Topics** (example):
1. Python for Data Science (4 days)
2. Statistics and Probability (5 days)
3. Data Manipulation with Pandas (4 days)
4. Data Visualization (3 days)
5. Machine Learning Fundamentals (7 days)
6. Model Evaluation and Validation (4 days)
7. Real-world Data Science Projects (3 days)

### Example 2: Learning Cloud Architecture

**Input**: "Become an AWS Solutions Architect"

**Generated Topics** (example):
1. Cloud Computing Fundamentals (3 days)
2. AWS Core Services (5 days)
3. Networking in AWS (4 days)
4. Security and IAM (4 days)
5. Serverless Architecture (5 days)
6. High Availability and Scaling (4 days)
7. Cost Optimization (3 days)
8. Architecture Best Practices (2 days)

## 🔍 Advanced Features

### Human-in-the-Loop (HITL)

The system pauses after curriculum generation to get user approval. This:
- Prevents wasted computation on unwanted content
- Allows users to refine their input if needed
- Demonstrates user-centric design
- Provides transparency into AI decision-making

### Dynamic Crew Invocation

Each topic gets its own ContentGenerationCrew instance:
- Enables parallel processing (future enhancement)
- Provides clear failure boundaries
- Allows for topic-specific customization
- Demonstrates scalable architecture

### Context Chaining

Tasks automatically receive context from predecessors:
```python
slides_task.context = [lesson_planning_task]
quiz_task.context = [slides_creation_task]
```

This ensures coherent, aligned content across all deliverables.

## 🚧 Future Enhancements

- **Parallel Processing**: Process multiple topics simultaneously
- **Streaming Output**: Display generation progress in real-time
- **Enhanced Parsing**: Use structured JSON output for easier parsing
- **Interactive Refinement**: Allow users to request revisions
- **Multi-Format Export**: Convert slides to PDF, PPTX, etc.
- **Progress Tracking**: Save progress for resumable sessions
- **Curriculum Templates**: Pre-built templates for common career paths

## 🤝 Contributing

This is a demonstration project showcasing agentic architecture patterns. Key areas for contribution:

1. **Enhanced Testing**: Add more edge case coverage
2. **Better Parsing**: Improve topic extraction from LLM output
3. **Output Formats**: Add export to various formats
4. **Agent Improvements**: Refine agent prompts and backstories
5. **Performance**: Optimize for speed and cost

## 📄 License

[Specify your license here]

## 🙏 Acknowledgments

- **CrewAI**: Framework for orchestrating role-playing AI agents
- **OpenAI**: GPT-4 language model powering all agents
- **Community**: Various online resources and best practices

## 📞 Contact

[Your contact information or project maintainer details]

---

## 🎯 Why This Architecture?

This project demonstrates several advanced concepts that impress technical recruiters:

1. **Hierarchical Design**: Two-level crew structure shows understanding of system decomposition
2. **Separation of Concerns**: Each agent has a single, clear responsibility
3. **Scalability**: Dynamic crew invocation supports growth
4. **Testing**: Comprehensive mocked tests show production mindset
5. **User-Centric**: HITL validation demonstrates focus on user needs
6. **Pragmatic Solutions**: LLM-powered tools show creative problem-solving within constraints
7. **Professional Structure**: Clean, modular codebase with thorough documentation
8. **Error Handling**: Graceful degradation and clear error messages
9. **Configurability**: Easy to modify and extend
10. **Production-Ready**: Proper logging, validation, and output management

This architecture could scale to handle:
- Multiple users simultaneously
- Different educational domains
- Various output formats
- Integration with learning management systems (LMS)
- Real-time collaboration features

---

**Built with ❤️ using CrewAI and OpenAI GPT-4**
