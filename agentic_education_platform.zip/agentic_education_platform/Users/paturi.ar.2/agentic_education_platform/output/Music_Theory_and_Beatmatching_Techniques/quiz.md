# Quiz: Music Theory and Beatmatching Techniques

## Questions

**Question 1**: What does BPM stand for in the context of music and DJing?  
A) Beats Per Measure  
B) Beats Per Minute  
C) Bars Per Measure  
D) Bass Per Melody  

---

**Question 2**: Why is phrasing important when performing a mix between two tracks?  
A) It helps DJs increase the volume at random intervals  
B) It ensures transitions occur at natural musical points, maintaining flow  
C) It allows DJs to change the key of the track smoothly  
D) It helps to quickly identify the BPM of the next track  

---

**Question 3**: When manually beatmatching two tracks, what technique is used to ensure both tracks’ beats align perfectly over time?  
A) Using volume faders to balance sound levels  
B) Nudging jog wheels or using nudge buttons to fine-tune phase alignment  
C) Increasing the bass frequencies in both tracks  
D) Applying echo effects on one track  

---

**Question 4**: Which of the following is a common cause of phase drift during a DJ performance?  
A) Both tracks having the same BPM and phrase length  
B) Incorrect BPM or slight tempo mismatch between tracks over time  
C) Using headphones to monitor incoming tracks  
D) Sync buttons adjusting phase automatically  

---

**Question 5**: When measuring BPM manually using the tap tempo method, what is the best practice?  
A) Tap once at the start of the track and assume the BPM stays constant  
B) Tap continuously along with the beat for several bars to get an accurate estimate  
C) Tap faster than the beat to speed up the calculation  
D) Tap only during the chorus to get the BPM  

---

## Answer Key

**Question 1**: Correct Answer: B  
**Explanation**: BPM stands for Beats Per Minute, the standard measurement of tempo in music. It indicates how many beats occur in one minute and is foundational for synchronizing tracks.  
- Distractors: A and C confuse terms related to musical structure; D is unrelated.

---

**Question 2**: Correct Answer: B  
**Explanation**: Phrasing ensures that DJs align transitions at natural points in the music (usually at phrase boundaries like 8 or 16 bars), maintaining a smooth and musical flow.  
- Distractors: A and C are unrelated to phrasing; D refers to BPM detection, not phrasing.

---

**Question 3**: Correct Answer: B  
**Explanation**: Nudging jog wheels or using nudge buttons allows DJs to fine-tune the timing (phase) of a track so its beats align perfectly with the other playing track.  
- Distractors: A is about volume, not beat alignment; C and D are unrelated to beatmatching techniques.

---

**Question 4**: Correct Answer: B  
**Explanation**: Phase drift occurs when there is a slight mismatch in tempo or BPM between tracks, causing beats to gradually go out of sync.  
- Distractors: A describes the ideal scenario; C and D describe monitoring/tools, not causes of drift.

---

**Question 5**: Correct Answer: B  
**Explanation**: Manually tapping along continuously with the beat over several bars helps average out timing variances and results in a more accurate BPM measurement.  
- Distractors: A, C, and D suggest poor or inaccurate practices that lead to unreliable BPM calculations.

---

This quiz covers key concepts of tempo, phrasing, beatmatching techniques, phase drift, and BPM measurement, with a range of difficulty and cognitive levels to fairly assess understanding of the lesson content.