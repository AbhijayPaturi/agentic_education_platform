# Quiz: Advanced Digital DJ Techniques and Effects Usage

## Questions

**Question 1:**  
Which parameter adjustment on a delay effect typically changes the number of repeating echoes heard in a mix?  
A) Dry/Wet Mix  
B) Feedback  
C) Rate Control  
D) Phase Offset  

---

**Question 2:**  
What is the main difference between serial and parallel effect routing in digital DJ setups?  
A) Serial routing blends dry signals while parallel routing processes effects one after the other  
B) Serial routing feeds the output of one effect into the input of the next; parallel routing runs effects side-by-side and blends outputs  
C) Parallel routing increases CPU usage more than serial routing  
D) Parallel routing is used only for reverbs, while serial routing is exclusive to delays  

---

**Question 3:**  
How can a low-pass filter sweep be used effectively during a live transition?  
A) It adds high-frequency sparkle to the incoming track  
B) It gradually removes highs to build tension before a drop  
C) It repeats the beat pattern to create a rhythmic delay effect  
D) It boosts the bass suddenly to surprise the audience  

---

**Question 4:**  
When integrating MIDI controllers with DJ software for effects control, what is one advantage of mapping effect parameters to physical knobs or faders?  
A) It eliminates the need for software updates  
B) It allows for tactile, real-time manipulation leading to more expressive performances  
C) It automatically improves CPU efficiency  
D) It prevents audio glitches and latency  

---

**Question 5:**  
Which of the following is NOT a recommended troubleshooting step to optimize your digital effects workflow during a live performance?  
A) Close unnecessary applications to free CPU resources  
B) Regularly update driver software to prevent glitches  
C) Increase buffer size excessively to the highest possible level for latency reduction  
D) Monitor signal levels closely to avoid clipping in effects chains  

---

## Answer Key

**Question 1:** Correct Answer: B  
**Explanation:** Feedback controls how much of the delayed signal is fed back into the effect, increasing the number of repeats. Dry/Wet mix controls blend amount; Rate affects speed; Phase offset is unrelated here.  

---

**Question 2:** Correct Answer: B  
**Explanation:** Serial routing chains effects one after another, with the output of one feeding into the input of the next, while parallel routing runs multiple effects simultaneously and blends their outputs with the dry signal. Options A, C, and D are inaccurate descriptions.  

---

**Question 3:** Correct Answer: B  
**Explanation:** A low-pass filter sweep removes high frequencies gradually, creating tension before a drop. Option A describes the opposite effect; C refers to beat repeat, and D inaccurately states a sudden bass boost.  

---

**Question 4:** Correct Answer: B  
**Explanation:** Mapping effect parameters to MIDI controllers enables hands-on, real-time control for more dynamic and expressive performances. It doesn’t inherently eliminate software updates nor affect CPU or glitches directly.  

---

**Question 5:** Correct Answer: C  
**Explanation:** Excessively increasing buffer size reduces CPU load but introduces high latency, negatively impacting live responsiveness. Best practice is optimizing buffer size for low latency. Closing apps, updating drivers, and monitoring levels are good practices.