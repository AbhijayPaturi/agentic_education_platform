{
  "topic": "Fundamentals of AI and Machine Learning",
  "quiz_type": "summative",
  "total_points": 80,
  "time_limit_minutes": 60,
  "questions": [
    {
      "question_number": 1,
      "question_type": "multiple_choice",
      "question": "What distinguishes Machine Learning (ML) from Artificial Intelligence (AI)?",
      "options": [
        "ML is the science of creating systems that mimic human intelligence, while AI focuses only on data processing.",
        "AI is a subset of ML focused on learning algorithms and data.",
        "ML is a subset of AI that involves algorithms improving through data without explicit programming.",
        "AI and ML are two unrelated fields."
      ],
      "correct_answer": "ML is a subset of AI that involves algorithms improving through data without explicit programming.",
      "explanation": "Machine Learning is specifically about algorithms improving automatically by learning from data, and it is a subset within the broader field of AI.",
      "difficulty": "Easy",
      "learning_objective_tested": "Understand the relationship between AI and ML"
    },
    {
      "question_number": 2,
      "question_type": "true_false",
      "question": "Deep Learning uses neural networks with many layers and is considered a subset of Machine Learning.",
      "options": null,
      "correct_answer": "True",
      "explanation": "Deep Learning applies neural network architectures with multiple layers for complex pattern learning and is a specialized subset of ML.",
      "difficulty": "Easy",
      "learning_objective_tested": "Identify hierarchical relationships among AI, ML, and Deep Learning"
    },
    {
      "question_number": 3,
      "question_type": "multiple_choice",
      "question": "Which of the following is NOT a type of machine learning?",
      "options": [
        "Supervised Learning",
        "Unsupervised Learning",
        "Reinforcement Learning",
        "Deterministic Learning"
      ],
      "correct_answer": "Deterministic Learning",
      "explanation": "Supervised, unsupervised, and reinforcement learning are established types of ML. Deterministic Learning is not a recognized ML category.",
      "difficulty": "Easy",
      "learning_objective_tested": "Recall types of machine learning"
    },
    {
      "question_number": 4,
      "question_type": "multiple_choice",
      "question": "In supervised learning, what is the purpose of labels in the training data?",
      "options": [
        "They allow the model to make random predictions.",
        "They serve as 'correct answers' guiding the model's learning process.",
        "They contain the input data features without outcomes.",
        "Labels help to evaluate the model after deployment only."
      ],
      "correct_answer": "They serve as 'correct answers' guiding the model's learning process.",
      "explanation": "Labels in supervised learning provide the known output for each input, allowing the model to learn correct mappings.",
      "difficulty": "Medium",
      "learning_objective_tested": "Understand the role of training data and labels"
    },
    {
      "question_number": 5,
      "question_type": "multiple_choice",
      "question": "Which metric would best measure how many actual positive cases were identified by a model?",
      "options": [
        "Accuracy",
        "Precision",
        "Recall",
        "Mean Squared Error"
      ],
      "correct_answer": "Recall",
      "explanation": "Recall measures the proportion of actual positives correctly identified, reflecting coverage of positive cases.",
      "difficulty": "Medium",
      "learning_objective_tested": "Interpret model evaluation metrics"
    },
    {
      "question_number": 6,
      "question_type": "true_false",
      "question": "Overfitting means a model performs well on training data but poorly on new unseen data.",
      "options": null,
      "correct_answer": "True",
      "explanation": "Overfitting occurs when a model learns noise or details from the training data that do not generalize, hurting performance on new data.",
      "difficulty": "Medium",
      "learning_objective_tested": "Recognize common ML deployment challenges"
    },
    {
      "question_number": 7,
      "question_type": "multiple_choice",
      "question": "Which of the following best describes feature engineering?",
      "options": [
        "The process of cleaning data before training a model.",
        "The selection and creation of relevant input variables to improve model learning.",
        "Running the trained model to make predictions.",
        "Evaluating a model's accuracy on the test dataset."
      ],
      "correct_answer": "The selection and creation of relevant input variables to improve model learning.",
      "explanation": "Feature engineering involves crafting input features from raw data to help models learn more effectively.",
      "difficulty": "Medium",
      "learning_objective_tested": "Understand data preprocessing and feature engineering"
    },
    {
      "question_number": 8,
      "question_type": "multiple_choice",
      "question": "What is the correct sequence step immediately after 'preprocessing and cleaning data' in a typical ML training workflow?",
      "options": [
        "Deploy model for inference",
        "Choose and train model",
        "Select relevant features",
        "Evaluate and refine"
      ],
      "correct_answer": "Select relevant features",
      "explanation": "After cleaning data, identifying relevant features is the next crucial step to improve model performance before training.",
      "difficulty": "Medium",
      "learning_objective_tested": "Recall steps in model training workflow"
    },
    {
      "question_number": 9,
      "question_type": "short_answer",
      "question": "Name one common challenge in deploying machine learning models that can result in unfair predictions.",
      "options": null,
      "correct_answer": "Data bias",
      "explanation": "Data bias occurs when training data contains prejudices or is unrepresentative, causing the model to make unfair or discriminatory decisions.",
      "difficulty": "Medium",
      "learning_objective_tested": "Identify challenges in ML deployment"
    },
    {
      "question_number": 10,
      "question_type": "multiple_choice",
      "question": "Which algorithm is typically used for predicting continuous numerical outcomes, such as house prices?",
      "options": [
        "Decision Trees",
        "K-Means Clustering",
        "Linear Regression",
        "Reinforcement Learning"
      ],
      "correct_answer": "Linear Regression",
      "explanation": "Linear Regression models establish relationships between independent variables and continuous outcomes for prediction.",
      "difficulty": "Easy",
      "learning_objective_tested": "Recognize common machine learning algorithms"
    },
    {
      "question_number": 11,
      "question_type": "multiple_choice",
      "question": "In the example Python code for training a Linear Regression model, what does the 'train_test_split' function do?",
      "options": [
        "Separates the dataset into training and testing subsets to evaluate the model fairly.",
        "Fits the model with the training data.",
        "Calculates the predictions from the model.",
        "Preprocesses the data by handling missing values."
      ],
      "correct_answer": "Separates the dataset into training and testing subsets to evaluate the model fairly.",
      "explanation": "The 'train_test_split' function divides data so that the model is trained on one set and tested on another to assess generalization.",
      "difficulty": "Hard",
      "learning_objective_tested": "Apply practical Python ML workflow concepts"
    },
    {
      "question_number": 12,
      "question_type": "multiple_choice",
      "question": "Which machine learning type learns by receiving rewards or penalties to optimize behavior over time?",
      "options": [
        "Supervised Learning",
        "Unsupervised Learning",
        "Reinforcement Learning",
        "Deep Learning"
      ],
      "correct_answer": "Reinforcement Learning",
      "explanation": "Reinforcement Learning involves agents learning optimal actions through trial, error, and feedback via rewards or penalties.",
      "difficulty": "Medium",
      "learning_objective_tested": "Distinguish among machine learning types"
    },
    {
      "question_number": 13,
      "question_type": "multiple_choice",
      "question": "Which ethical consideration in AI design ensures that the decision processes can be understood and trusted by users?",
      "options": [
        "Privacy",
        "Explainability",
        "Bias and fairness",
        "Scalability"
      ],
      "correct_answer": "Explainability",
      "explanation": "Explainability focuses on making AI's internal decisions transparent and interpretable to build trust and accountability.",
      "difficulty": "Medium",
      "learning_objective_tested": "Understand ethical issues in AI"
    },
    {
      "question_number": 14,
      "question_type": "true_false",
      "question": "Unsupervised learning always requires labeled data to discover patterns.",
      "options": null,
      "correct_answer": "False",
      "explanation": "Unsupervised learning specifically works with unlabeled data to find hidden structures or groupings without predefined outcomes.",
      "difficulty": "Easy",
      "learning_objective_tested": "Clarify types of machine learning"
    },
    {
      "question_number": 15,
      "question_type": "multiple_choice",
      "question": "Which of the following is a real-world application of machine learning in finance?",
      "options": [
        "Disease diagnosis",
        "Fraud detection",
        "Customer segmentation",
        "Personalized treatments"
      ],
      "correct_answer": "Fraud detection",
      "explanation": "Machine learning models are widely used in finance to detect fraudulent transactions by identifying suspicious patterns.",
      "difficulty": "Easy",
      "learning_objective_tested": "Recognize applications of ML across industries"
    }
  ],
  "passing_score": 70,
  "study_tips": "Review the definitions of AI, ML, and Deep Learning carefully. Understand key terminology such as algorithms, models, and training. Focus on the differences between types of machine learning and their use cases. Practice interpreting model evaluation metrics and be comfortable with the machine learning workflow steps. Reflect on ethical considerations to appreciate the broader context of AI applications."
}