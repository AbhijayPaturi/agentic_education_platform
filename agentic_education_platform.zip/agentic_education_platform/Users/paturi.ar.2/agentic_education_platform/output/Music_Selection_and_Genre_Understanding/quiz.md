# Quiz: Music Selection and Genre Understanding

## Questions

**Question 1**: Which of the following best defines a music genre?  
A) A specific song performed by famous artists  
B) A category characterized by shared musical features like style and rhythm  
C) A random collection of songs chosen by a DJ  
D) The mood a listener feels when hearing music  

---

**Question 2**: Which characteristic is most typical of jazz music?  
A) Catchy melodies and repetitive structure  
B) Improvisation and swing rhythms  
C) Synthesized sounds and dance beats  
D) Strong backbeat with electric guitars  

---

**Question 3**: How does understanding the audience influence music selection?  
A) It determines the copyright permissions needed  
B) It shapes choices based on listeners’ age, cultural background, and preferences  
C) It dictates the number of songs in a playlist  
D) It ensures all songs are from the same genre  

---

**Question 4**: A song featuring rap verses layered over electronic dance beats is an example of what?  
A) A purely electronic track  
B) A genre crossover blending hip-hop and electronic music  
C) A classical remix  
D) A traditional rock ballad  

---

**Question 5**: When curating a playlist for a formal dinner, which of the following criteria is most appropriate to consider?  
A) Choosing upbeat hip-hop tracks for high energy  
B) Selecting slow tempo, calm, and structured music like soft classical  
C) Picking fast, dance-oriented electronic music  
D) Including mostly improvisational jazz solos at high volume  

---

## Answer Key

**Question 1**: Correct Answer: B  
**Explanation**: A music genre is defined by shared musical characteristics such as style, mood, instrumentation, and rhythm, which helps categorize and understand music.  
*Distractors*: A is just a specific song, not a category; C is random collection, not a defining concept; D describes mood, not genre definition.

**Question 2**: Correct Answer: B  
**Explanation**: Jazz is known for its improvisation and swing rhythms, which distinguish it from other genres.  
*Distractors*: A describes pop, C describes electronic, and D describes rock characteristics.

**Question 3**: Correct Answer: B  
**Explanation**: Audience understanding guides music selection by aligning with listeners’ demographics and taste, ensuring relevance and engagement.  
*Distractors*: A is about legal concerns, not audience; C and D are not directly influenced by audience traits.

**Question 4**: Correct Answer: B  
**Explanation**: The described song mixes rap (hip-hop) with electronic beats, illustrating a genre crossover blending features of both.  
*Distractors*: A ignores the rap element, C and D are unrelated genres.

**Question 5**: Correct Answer: B  
**Explanation**: For a formal dinner, music that is calm, structured, and slow tempo (like soft classical) suits the atmosphere best.  
*Distractors*: A, C, and D describe energetic or potentially distracting music inappropriate for formal dining.

---

This quiz covers defining genres, identifying key characteristics, understanding audience impact on selection, recognizing genre crossover, and applying selection criteria contextually, fulfilling knowledge, comprehension, and application levels.