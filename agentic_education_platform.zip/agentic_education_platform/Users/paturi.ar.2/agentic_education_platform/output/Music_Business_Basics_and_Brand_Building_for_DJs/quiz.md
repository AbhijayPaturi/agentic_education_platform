# Quiz: Music Business Basics and Brand Building for DJs

## Questions

**Question 1**: What is the primary purpose of registering your music with a Performance Rights Organization (PRO)?  
A) To promote your music on social media  
B) To collect royalties from public performances and broadcasts  
C) To create your DJ logo and brand image  
D) To secure live performance contracts  

---

**Question 2**: Which of the following best describes an essential characteristic of a strong DJ brand?  
A) Changing your brand style frequently to follow trends  
B) Having a consistent identity expressed through name, logo, visuals, and sound  
C) Using complex and hard-to-spell DJ names to appear unique  
D) Avoiding any personal connection with fans to maintain professionalism  

---

**Question 3**: When reviewing a contract for a DJ gig or collaboration, which term is the most important to clarify before signing?  
A) The color scheme of your promotional materials  
B) The exact payment amount and usage rights for your music  
C) The type of merchandise to sell at the event  
D) The follower count on your social media profiles  

---

**Question 4**: A DJ wants to increase online fan engagement effectively. Based on effective strategies discussed, what should they prioritize?  
A) Posting weekly mixes and sharing behind-the-scenes content regularly  
B) Posting random content irregularly across many unrelated platforms  
C) Avoiding interaction with fans to keep an exclusive image  
D) Only using paid advertising without organic posts  

---

**Question 5**: Which of the following is NOT considered a typical revenue stream for DJs?  
A) Live performances and residencies  
B) Licensing music for commercials or films  
C) Selling branded merchandise like T-shirts and hats  
D) Hiring a manager to handle bookings  

---

## Answer Key

**Question 1**: Correct Answer: B  
**Explanation**: PROs collect royalties on behalf of artists when their music is played publicly, ensuring DJs earn income from broadcasts and public performances. Options A, C, and D pertain to promotion, branding, or contracts, not royalty collection.

---

**Question 2**: Correct Answer: B  
**Explanation**: Consistency in branding—across your name, logo, visuals, and sound—is crucial for recognition and building fan loyalty. Frequent changes (A), complicated names (C), or emotional distance from fans (D) weaken brand connection.

---

**Question 3**: Correct Answer: B  
**Explanation**: Clarifying payment and usage rights is essential to ensure DJs are fairly compensated and understand how their music can be used. The other options (A, C, D) are unrelated to fundamental contract terms.

---

**Question 4**: Correct Answer: A  
**Explanation**: Regular, relevant content like weekly mixes and personal stories engages fans and builds loyalty effectively. Irregular posting (B), avoiding fan interaction (C), and relying solely on paid ads (D) are less effective strategies.

---

**Question 5**: Correct Answer: D  
**Explanation**: Hiring a manager is a business decision, not a revenue stream. Live gigs (A), licensing (B), and merchandise sales (C) generate direct income for DJs.