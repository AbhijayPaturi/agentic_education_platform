# Quiz: Introduction to DJ Equipment and Software

## Questions

**Question 1**: Which piece of DJ hardware is primarily used to blend audio signals from multiple sources and control volume and effects?  
A) Turntable  
B) Mixer  
C) CDJ  
D) Audio Interface  

---

**Question 2**: What is the main purpose of headphones in a DJ setup?  
A) To amplify sound for the audience  
B) To cue and beatmatch tracks without the audience hearing  
C) To record live sessions  
D) To connect decks to the mixer  

---

**Question 3**: In DJ software, what feature allows you to mark specific parts of a track for repeated playback or creative mixing?  
A) Library Management  
B) Waveform Display  
C) Cue Points & Loops  
D) Beatmatching Tools  

---

**Question 4**: When setting up your DJ rig, what is the correct signal flow order from source to speakers?  
A) Mixer → Decks → Audio Interface → Speakers  
B) Audio Interface → Decks → Mixer → Speakers  
C) Decks → Mixer → Audio Interface → Speakers  
D) Decks → Audio Interface → Mixer → Speakers  

---

**Question 5**: If you experience delayed audio response during a performance, which troubleshooting action is recommended?  
A) Increase the latency buffer size in the software settings  
B) Reduce the latency buffer size in the software settings  
C) Disconnect the headphones  
D) Replace the audio cables with longer ones  

---

## Answer Key

**Question 1**: Correct Answer: B  
**Explanation**: Mixers blend audio from multiple sources and provide control over volume and effects. Turntables and CDJs are sources, and audio interfaces handle signal conversion but not mixing.

---

**Question 2**: Correct Answer: B  
**Explanation**: Headphones allow DJs to listen privately to upcoming tracks for cueing and beatmatching without the audience hearing, enabling smooth transitions.

---

**Question 3**: Correct Answer: C  
**Explanation**: Cue points and loops let DJs mark specific track points and repeat sections creatively during mixing, distinguishing them from library management or waveform displays.

---

**Question 4**: Correct Answer: C  
**Explanation**: The standard signal flow is decks feeding audio into the mixer, then the mixer outputting through the audio interface to the speakers.

---

**Question 5**: Correct Answer: B  
**Explanation**: Reducing the latency buffer size minimizes delay between playing and hearing audio, improving responsiveness during performance. Increasing latency causes more delay, and cables or headphones do not fix latency issues.