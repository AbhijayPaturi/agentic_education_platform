# Quiz: Marketing, Networking, and Business Fundamentals for DJs

## Questions

**Question 1**: What is a primary purpose of marketing for DJs?  
A) To teach music theory concepts to beginners  
B) To promote their music and performances to build a fanbase  
C) To negotiate contracts with event venues  
D) To track financial expenses and taxes

---

**Question 2**: Which of the following best exemplifies building a DJ’s personal brand?  
A) Sharing your unique sound and consistent visuals like logo and colors  
B) Sending invoices to promoters promptly after gigs  
C) Learning to use complicated DJ software quickly  
D) Hiring a lawyer to review your contracts

---

**Question 3**: Which strategy is most effective for networking in the music industry?  
A) Only contacting promoters after you have a large fan base  
B) Attending music events and building genuine relationships with industry insiders  
C) Posting daily mixes without interacting with listeners  
D) Avoiding collaborations to maintain complete creative control

---

**Question 4**: When reviewing a DJ contract, which element is most important to understand?  
A) The cancellation policy specifying notice period  
B) The preferred music genre of the venue owner  
C) The color scheme used in promotional materials  
D) The number of followers on your social media platforms

---

**Question 5**: What is a key financial management practice for DJs to sustain their career?  
A) Tracking earnings, expenses, and saving for slower periods  
B) Only spending money on new gear when profits exceed $10,000  
C) Avoiding budgeting to focus on creative work  
D) Using unverified payment methods to get paid faster

---

## Answer Key

**Question 1**: Correct Answer: B  
**Explanation**: Marketing’s main role for DJs is to promote their music and performances so they can build a fanbase and attract promoters. Options A, C, and D relate to other areas but not marketing’s core purpose.

**Question 2**: Correct Answer: A  
**Explanation**: Building a personal brand involves creating a unique sound and consistent visuals that make a DJ memorable. Sending invoices, software skills, and legal advice are important but not directly related to brand building.

**Question 3**: Correct Answer: B  
**Explanation**: Effective networking in music is about attending events and creating genuine connections with other industry professionals. Simply posting content or avoiding collaborations does not build meaningful relationships.

**Question 4**: Correct Answer: A  
**Explanation**: Understanding key contract elements like cancellation policies protects a DJ’s rights and finances. The color scheme or genre preferences are not contract essentials, and social media followers are unrelated to contract terms.

**Question 5**: Correct Answer: A  
**Explanation**: Keeping track of earnings, expenses, and saving money for slow periods are fundamental financial practices that help DJs sustain their careers. Ignoring budgeting or unsafe payment methods can cause financial problems.

---

This quiz covers knowledge, comprehension, and application of marketing, networking, branding, contracts, and finances relevant for DJs, with clear wording and plausible distractors to gauge and deepen understanding.