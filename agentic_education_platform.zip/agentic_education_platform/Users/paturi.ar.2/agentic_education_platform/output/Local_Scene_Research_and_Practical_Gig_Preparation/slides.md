## Local Scene Research and Practical Gig Preparation

An introduction to understanding your local music/performance scene and preparing effectively for live gigs.

---

## Learning Objectives

- Identify key characteristics of local music and performance scenes
- Analyze audience demographics and venue dynamics
- Develop networking and communication skills within the scene
- Create tailored setlists for specific venues and audiences
- Plan logistical details essential for gig day success

---

## Understanding the Local Scene

- Definition: The network and culture surrounding local music or performance communities  
- Importance: Builds a foundation for meaningful opportunities and audience engagement  
- Venue types: Clubs, bars, theaters, outdoor spaces, pop-ups  
- Example: A hip-hop open mic night vs. a jazz lounge showcase

---

## Researching Your Local scene

- Use online platforms: Event calendars, social media, local blogs  
- Engage with local publications, flyers, word-of-mouth  
- Participate and observe events to gather firsthand insights  
- Analogy: Researching the scene is like scouting terrain before a journey – know your landscape!

---

## Analyzing Venues and Audiences

- Venue factors: size, capacity, acoustics, atmosphere  
- Audience demographics: age ranges, cultural interests, attendance patterns  
- Matching performance style to venue vibe and audience preferences  
- Example: High-energy set in a club vs. intimate acoustic set in a café

---

## Networking within the Local Scene

- Why network? Increases gig opportunities and learning  
- Communication tips: Follow up, be genuine, show professionalism  
- Use social media & attend in-person events to connect with promoters and artists  
- Role play tip: Prepare an elevator pitch introducing yourself and your music

---

## Creating Effective Setlists

- Consider audience and venue: timeslot length, energy flow, crowd response  
- Balance: New material + crowd favorites for engagement  
- Structure: Opening, peak moments, encore possibilities  
- Example setlist order for a 45-minute gig:
  1. Upbeat opener  
  2. Mid-tempo songs  
  3. Crowd-pleasing hit  
  4. New or experimental piece  
  5. High-energy closer

---

## Rehearsal Strategies

- Plan rehearsals reflecting gig conditions  
- Practice transitions and timing for seamless performance  
- Simulate live conditions with band or solo  
- Checklist: Prepare backup gear, set practice goals, record rehearsals for review

---

## Gig Day Logistics

- Equipment checklist: instruments, cables, backups, set lists  
- Soundcheck: test audio levels, setup time  
- Travel & timing: plan arrival, load-in/load-out schedules  
- Mental prep: rest, warm-up routines, visualization techniques

---

## Managing Venue Interactions

- Communicate respectfully with venue staff and sound engineers  
- Understand stage setup and sound limitations  
- Be adaptable to unexpected changes  
- Tip: Have a quick contact list including promoter and tech support

---

## Summary: Key Takeaways

- Local scene knowledge is critical to gig success  
- Audience and venue analysis tailor your performance  
- Networking opens doors and strengthens your presence  
- A well-crafted setlist and strategic rehearsals boost confidence  
- Detailed logistical planning ensures smooth performance days

---

## Additional Resources

- Websites: Bandsintown, Songkick, Meetup (local events)  
- Books: "How to Make It in the New Music Business" by Ari Herstand  
- YouTube Channels: DIY Musicians, Behind The Gig  
- Local Music Forums and Facebook Groups for networking

---