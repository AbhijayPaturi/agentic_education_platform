# Quiz: Local Scene Research and Practical Gig Preparation

## Questions

**Question 1**: What is the primary reason for researching your local music scene before performing live?  
A) To copy other artists’ styles exactly  
B) To understand the network and culture surrounding local music communities  
C) To get free equipment for your gig  
D) To avoid performing in crowded venues  

---

**Question 2**: Which factor is most important when analyzing a venue to tailor your performance?  
A) The number of parking spots available  
B) Venue size, acoustics, and atmosphere  
C) The popularity of food served at the venue  
D) The décor style of the building  

---

**Question 3**: When preparing a setlist for a 45-minute gig, which strategy best balances audience engagement?  
A) Play only new, experimental songs throughout  
B) Start with a high-energy opener and include crowd favorites, new material, and a high-energy closer  
C) Perform slow, acoustic songs exclusively to calm the audience  
D) Play songs randomly without considering energy flow or audience response  

---

**Question 4**: What is a key networking tip to increase gig opportunities within your local scene?  
A) Avoid attending events you are not performing at  
B) Only communicate through social media and never in person  
C) Follow up with contacts, be genuine, and show professionalism  
D) Demand immediate bookings when meeting promoters  

---

**Question 5**: Which of the following is NOT an essential gig day logistics preparation step?  
A) Planning your arrival time and load-in schedule  
B) Preparing backup gear and performing a soundcheck  
C) Ignoring mental prep to save time on gig day  
D) Having a quick contact list of promoters and tech support  

---

## Answer Key

**Question 1**: Correct Answer: B  
**Explanation**: Understanding the local scene’s network and culture helps performers connect with the right audiences and opportunities. Options A, C, and D do not reflect the primary purpose of local scene research.

---

**Question 2**: Correct Answer: B  
**Explanation**: Venue size, acoustics, and atmosphere directly impact your performance style and how well your music fits the location. Parking, food, and décor are less relevant factors.

---

**Question 3**: Correct Answer: B  
**Explanation**: A well-balanced setlist includes an engaging flow of energy, mixing crowd favorites with new material and peaks at the start and end, to keep audience interest. Other options neglect balance and engagement.

---

**Question 4**: Correct Answer: C  
**Explanation**: Effective networking involves genuine communication, professionalism, and following up. Avoiding events or demanding bookings can harm relationships; only online communication limits opportunities.

---

**Question 5**: Correct Answer: C  
**Explanation**: Mental preparation is essential for performance confidence and focus. Ignoring it can negatively affect gig success, while travel planning, soundchecks, gear, and contacts are practical essentials.