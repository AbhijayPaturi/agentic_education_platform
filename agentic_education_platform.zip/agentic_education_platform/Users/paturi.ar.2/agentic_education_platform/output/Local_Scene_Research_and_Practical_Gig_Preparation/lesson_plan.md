# Lesson Plan: Local Scene Research and Practical Gig Preparation

## Overview  
This topic introduces students to the process of researching a local music or performance scene, understanding its dynamics, and preparing effectively for live gigs. It equips learners with both theoretical knowledge of audience and venue analysis and practical skills such as networking, setlist creation, and logistics planning to optimize live performance opportunities.

## Learning Objectives  
1. Identify key characteristics of local music/performance scenes and venues.  
2. Analyze audience demographics and preferences to tailor performance choices.  
3. Develop practical skills in networking and communication within the local scene.  
4. Create effective setlists tailored to venue and audience dynamics.  
5. Plan and organize the logistical requirements of a gig from start to finish.

## Lessons

### Lesson 1: Introduction to Local Scene Research  
- **Objective:** Understand the concept of a local scene and learn methods for researching it effectively.  
- **Key Concepts:**  
  - Definition and importance of a local scene  
  - Types of venues and event formats in the scene  
  - Sources for scene research (online platforms, local publications, social media, word-of-mouth)  
- **Duration:** 45 minutes  
- **Approach:** Interactive lecture with real-world examples; group discussion to identify local venues or scenes students are aware of; guided online demo showing how to gather scene information using websites, social media, and event calendars.

### Lesson 2: Audience and Venue Analysis  
- **Objective:** Analyze venue characteristics and audience demographics to inform performance decisions.  
- **Key Concepts:**  
  - Venue size, capacity, acoustics, and vibe  
  - Audience demographics: age, interests, cultural background  
  - Matching performance style and setlist to venue and audience  
- **Duration:** 50 minutes  
- **Approach:** Case studies of different local venues; worksheet exercise mapping venue features and intended audience profiles; small group brainstorming on how to adapt performance approach for different venues.

### Lesson 3: Networking and Building Local Connections  
- **Objective:** Develop practical networking skills to build relationships within the local scene.  
- **Key Concepts:**  
  - Importance of networking for gig opportunities  
  - Effective communication and follow-up techniques  
  - Using social media and in-person events to connect with venue owners, promoters, and artists  
- **Duration:** 45 minutes  
- **Approach:** Role-playing networking scenarios; creating a local scene contact list template; guided activity to draft introductory messages or conversation starters.

### Lesson 4: Setlist Preparation and Rehearsal Strategies  
- **Objective:** Create tailored setlists and develop rehearsal plans that suit the gig context.  
- **Key Concepts:**  
  - Factors influencing setlist order and song choice (audience, venue time slots, energy flow)  
  - Balancing new material with crowd favorites  
  - Practical rehearsal techniques for readiness and flexibility  
- **Duration:** 50 minutes  
- **Approach:** Workshop format where students develop a sample setlist for a specific venue and audience; peer review of setlists; rehearsal planning checklist creation.

### Lesson 5: Gig Logistics and Performance Day Preparation  
- **Objective:** Plan and organize all logistical aspects of gig day to ensure smooth execution.  
- **Key Concepts:**  
  - Equipment checklist and soundcheck procedures  
  - Travel and timing considerations  
  - Managing stage setup, sound levels, and interaction with venue staff  
  - Preparing mentally and physically for performance  
- **Duration:** 55 minutes  
- **Approach:** Group discussion on common logistical challenges; creation of a gig day timeline template; guided planning of a mock gig day from load-in to load-out.

## Assessment Strategy  
- **Practical Portfolio:** Students will submit a portfolio including:  
  - A local scene research report for their area or a chosen scene, with venue and audience analysis.  
  - A network contact list with communication drafts used.  
  - A tailored setlist and rehearsal plan.  
  - A detailed gig day logistic plan.  
- **Reflective Journal:** Students will reflect on how their understanding of the local scene influenced their gig preparation and decision-making.  
- **Presentation:** Optional group presentations on a researched local scene and proposed gig preparation strategy to demonstrate comprehension and application.  

These assessments collectively validate both the theoretical knowledge and practical skills critical to success in local scene research and gig preparation.