# Quiz: Performance and Crowd Interaction Skills

## Questions

**Question 1**: Which of the following is NOT considered a key element of strong stage presence?  
A) Purposeful movement  
B) Slouching posture  
C) Vocal projection  
D) Eye contact and facial expressions  

---

**Question 2**: If a performer notices that the audience is restless and not engaging verbally, what is the best immediate strategy based on reading crowd dynamics?  
A) Continue with the original script without change  
B) Increase vocal volume and use more energetic gestures  
C) Lower vocal tone and avoid eye contact to not irritate the crowd  
D) Ignore the crowd and move quickly to end the performance  

---

**Question 3**: What is an effective verbal interaction technique to encourage audience participation?  
A) Asking closed-ended questions that require yes/no answers  
B) Delivering a lengthy monologue without breaks  
C) Asking open-ended questions that invite discussion  
D) Avoiding any interruptions by audience members  

---

**Question 4**: During a performance, a smartphone rings loudly. According to managing stage presence under pressure, what is the best response?  
A) Pause and angrily reprimand the audience member  
B) Ignore the distraction and continue speaking as if nothing happened  
C) Make a light-hearted comment to defuse tension and continue  
D) Stop the performance and wait for the room to quiet down  

---

**Question 5**: When setting goals to improve performance skills, what does the acronym SMART stand for?  
A) Specific, Measurable, Achievable, Relevant, Time-bound  
B) Simple, Manageable, Attainable, Realistic, Timely  
C) Smart, Motivated, Ambitious, Reasonable, Tested  
D) Strategic, Methodical, Adaptable, Reliable, Thoughtful  

---

## Answer Key

**Question 1**: Correct Answer: B  
**Explanation**: Slouching posture undermines stage presence by projecting low confidence, unlike purposeful movement, vocal projection, and eye contact which enhance engagement.

---

**Question 2**: Correct Answer: B  
**Explanation**: Noticing a restless crowd, increasing vocal energy and using dynamic gestures can recapture attention. Ignoring crowd cues or avoiding engagement would likely worsen disinterest.

---

**Question 3**: Correct Answer: C  
**Explanation**: Open-ended questions invite audience participation and thoughtful engagement, unlike closed-ended questions or monologues which limit interaction.

---

**Question 4**: Correct Answer: C  
**Explanation**: Using humor or a light comment helps manage pressure, maintains professionalism, and smoothly recovers from unexpected interruptions. Angry reprimands or ignoring may alienate the audience.

---

**Question 5**: Correct Answer: A  
**Explanation**: SMART goals are Specific, Measurable, Achievable, Relevant, and Time-bound, providing a clear framework for effective skill development. Other options use incorrect or mixed terms.

---

This quiz effectively covers key concepts of stage presence, crowd dynamics, verbal/non-verbal techniques, pressure management, and goal setting from the lesson. The questions vary in difficulty and cognitive level, with plausible distractors testing understanding without ambiguity.