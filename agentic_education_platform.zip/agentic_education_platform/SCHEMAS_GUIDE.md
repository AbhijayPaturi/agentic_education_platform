# Using Pydantic Schemas with CrewAI Agents

## Overview

CrewAI supports **structured input/output schemas** using Pydantic models, similar to LangChain's approach. This provides:

- ✅ **Type Safety**: Automatic validation of agent outputs
- ✅ **Clear Contracts**: Each agent knows exactly what format to produce
- ✅ **Better Context Passing**: Structured data flows between agents
- ✅ **Easier Debugging**: Validation errors caught early with clear messages
- ✅ **JSON Serialization**: Easy to save/load structured outputs

## How to Use Schemas in Tasks

### Option 1: JSON Schema Output (Flexible)

Use `output_json` parameter to specify a Pydantic model:

```python
from agents.schemas import LessonPlan
from crewai import Task

task = Task(
    description="Create a detailed lesson plan...",
    expected_output="A structured lesson plan with objectives, lessons, and assessment",
    agent=teacher_agent,
    output_json=LessonPlan  # Pydantic model class
)
```

The agent will:
1. Generate output matching the schema
2. Return a dictionary that can be validated
3. Automatically convert to JSON if needed

### Option 2: Pydantic Output (Strict)

Use `output_pydantic` for strict validation:

```python
task = Task(
    description="Create a detailed lesson plan...",
    expected_output="A structured lesson plan",
    agent=teacher_agent,
    output_pydantic=LessonPlan  # Returns validated Pydantic instance
)
```

This enforces stricter validation and returns a Pydantic model instance directly.

## Example: Converting Existing Tasks to Use Schemas

### Before (Text Output)

```python
@staticmethod
def create_lesson_planning_task(teacher_agent, topic: str) -> Task:
    return Task(
        description=f"Create a detailed lesson plan for: '{topic}'...",
        expected_output="A comprehensive lesson plan in Markdown format...",
        agent=teacher_agent,
        output_file=str(output_file)
    )
```

### After (Structured Output)

```python
from agents.schemas import LessonPlan

@staticmethod
def create_lesson_planning_task(teacher_agent, topic: str) -> Task:
    return Task(
        description=f"Create a detailed lesson plan for: '{topic}'...",
        expected_output="A structured lesson plan following the LessonPlan schema",
        agent=teacher_agent,
        output_json=LessonPlan,  # Add schema
        output_file=str(output_file)
    )
```

## Passing Structured Context Between Tasks

When using schemas, context passing becomes more powerful:

```python
# Task 1: Generate lesson plan (returns LessonPlan)
lesson_task = Task(
    description="Create lesson plan...",
    agent=teacher_agent,
    output_json=LessonPlan
)

# Task 2: Use lesson plan context (receives structured data)
slides_task = Task(
    description="""
    Create slides based on the lesson plan.
    
    You will receive a LessonPlan object with:
    - learning_objectives: List of LearningObjective objects
    - lessons: List of LessonDetail objects
    - assessment_strategy: String
    
    Use this structured data to create aligned slides.
    """,
    agent=slides_agent,
    context=[lesson_task],  # Receives LessonPlan structure
    output_json=PresentationSlides
)
```

## Working with Structured Outputs

### Accessing Task Results

```python
# After crew execution
crew_result = crew.kickoff(inputs={'topic': 'Python Basics'})

# Access individual task outputs
for task in crew.tasks:
    if hasattr(task.output, 'pydantic'):
        # If using output_pydantic
        structured_output = task.output.pydantic
        print(f"Topic: {structured_output.topic}")
        print(f"Total lessons: {len(structured_output.lessons)}")
    elif hasattr(task.output, 'json_dict'):
        # If using output_json
        json_data = task.output.json_dict
        print(f"Topic: {json_data['topic']}")
```

### Saving Structured Outputs

```python
import json
from pathlib import Path

def save_structured_output(task, output_path: Path):
    """Save structured output to both JSON and Markdown."""
    
    if hasattr(task.output, 'json_dict'):
        # Save as JSON
        json_path = output_path.with_suffix('.json')
        with open(json_path, 'w') as f:
            json.dump(task.output.json_dict, f, indent=2)
        
        # Also save as readable Markdown
        md_path = output_path.with_suffix('.md')
        with open(md_path, 'w') as f:
            # Convert structured data to Markdown
            f.write(format_as_markdown(task.output.json_dict))
```

## Benefits Over Plain Text

### 1. Validation

```python
from agents.schemas import Quiz

# Automatically validates:
# - Required fields present
# - Correct data types
# - Value constraints (e.g., 10-15 questions)
# - Field descriptions help LLM generate correct format
```

### 2. Type-Safe Access

```python
# Instead of parsing text:
lesson_text = task.output.raw
objectives = extract_objectives(lesson_text)  # Error-prone

# Use structured data:
lesson_plan = task.output.pydantic  # Type-safe
for obj in lesson_plan.learning_objectives:
    print(f"{obj.objective} ({obj.blooms_level})")
```

### 3. Better LLM Performance

Pydantic field descriptions act as **implicit instructions** to the LLM:

```python
class QuizQuestion(BaseModel):
    question_type: str = Field(
        description="Type: multiple_choice, true_false, short_answer, code_problem"
    )
    # LLM knows exactly what values are acceptable ↑
    
    difficulty: str = Field(
        description="Easy, Medium, or Hard"
    )
    # Clear enumeration helps LLM choose correctly ↑
```

## Implementation Checklist

To add schemas to your existing system:

1. ✅ **Created schemas** in `agents/schemas.py`
2. ⬜ **Update task definitions** to use `output_json` or `output_pydantic`
3. ⬜ **Update task descriptions** to reference schema structure
4. ⬜ **Modify save functions** to handle both structured and text outputs
5. ⬜ **Add validation** using schema validation functions
6. ⬜ **Update tests** to verify schema compliance

## Example: Full Structured Workflow

```python
from agents.schemas import (
    CurriculumProposal,
    LessonPlan,
    PresentationSlides,
    VideoResources,
    Quiz
)

# Create curriculum with schema
curriculum_task = Task(
    description="Analyze career goal and propose curriculum...",
    expected_output="Structured curriculum following CurriculumProposal schema",
    agent=principal_agent,
    output_json=CurriculumProposal
)

# Access structured output
curriculum = crew.kickoff()
curriculum_data = curriculum_task.output.json_dict

# Extract topics with type safety
for topic in curriculum_data['topics']:
    print(f"Topic: {topic['topic_name']}")
    print(f"Days: {topic['days_allocated']}")
    print(f"Order: {topic['order']}")
```

## Trade-offs

### When to Use Schemas

✅ **Good for:**
- Inter-agent communication (structured context)
- Validation-critical outputs
- Programmatic processing of results
- Building dashboards/UIs from outputs

❌ **Consider plain text for:**
- End-user facing content (blog posts, articles)
- Creative/free-form outputs
- Rapid prototyping
- When flexibility matters more than structure

## Next Steps

1. **Test with one task**: Start by adding schema to quiz task (simplest)
2. **Validate**: Check that outputs match schema
3. **Expand**: Add schemas to other tasks incrementally
4. **Hybrid approach**: Use schemas for structure, Markdown for presentation

## Resources

- CrewAI Output Types: https://docs.crewai.com/core-concepts/Tasks/#task-output
- Pydantic Documentation: https://docs.pydantic.dev/
- Schema Design Patterns: See `agents/schemas.py` for examples
