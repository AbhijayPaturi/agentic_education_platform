# Repository Restructuring Guide

## Overview

This repository has been restructured from a **type-based** organization to a **component-based** (functionality-based) organization. This is a best practice for building scalable, maintainable software systems, including AI agent systems.

## What Changed?

### Old Structure (Type-Based)
```
agents/
  agents.py          # ALL agents defined here
  tasks.py           # ALL tasks defined here
  schemas.py         # ALL schemas defined here
app/
  main.py            # 600+ lines of orchestration code
```

**Problems with this approach:**
- Related code scattered across multiple files
- Difficult to understand what belongs together
- Hard to modify one agent without affecting others
- Main.py becomes bloated with business logic
- Poor encapsulation and modularity

### New Structure (Component-Based)
```
agents/
  principal/         # Principal agent component
    __init__.py
    agent.py         # Agent definition + task creation functions
    schemas.py       # Principal-specific schemas
  teacher/           # Teacher agent component
    __init__.py
    agent.py
    schemas.py
  slides/            # Slides agent component
    __init__.py
    agent.py
    schemas.py
  video/             # Video agent component
    __init__.py
    agent.py
    schemas.py
  test/              # Test agent component
    __init__.py
    agent.py
    schemas.py
crews/               # Crew definitions
  __init__.py
  curriculum_crew.py           # How agents form CurriculumCrew
  content_generation_crew.py   # How agents form ContentGenerationCrew
utils/               # Shared utilities
  __init__.py
  output_utils.py    # Output formatting and saving
app/
  main_new.py        # Clean entry point (~200 lines)
```

**Benefits of this approach:**
- Each agent is a self-contained component
- All related code (agent, tasks, schemas) lives together
- Easy to understand agent responsibilities
- Easy to add/modify/remove agents
- Crews directory shows how agents collaborate
- Main.py is clean and focused on orchestration only
- Better testability and maintainability

## Key Principles

### 1. Component Cohesion
Each agent directory contains everything related to that agent:
- Agent definition (role, goal, backstory, tools)
- Task creation functions (with dynamic input support)
- Schemas specific to that agent's outputs

### 2. Separation of Concerns
- **agents/**: Individual agent components
- **crews/**: How agents work together as teams
- **utils/**: Shared utility functions
- **app/**: Application entry point and flow control

### 3. Encapsulation
Each agent component exports a clean interface:
```python
from agents.principal import (
    create_principal_agent,
    create_topic_identification_task,
    CurriculumProposal,
    TopicProposal
)
```

### 4. Crew as Composition
Crews compose agents and tasks into teams:
```python
class CurriculumCrew:
    def __init__(self, user_name, career_goal):
        self.principal = create_principal_agent()
        self.topic_task = create_topic_identification_task(
            self.principal, user_name, career_goal
        )
        self.crew = Crew(
            agents=[self.principal],
            tasks=[self.topic_task],
            process=Process.sequential
        )
```

### 5. Clean Entry Point
Main.py focuses only on:
- User input
- Running crews
- Processing results
- User interaction

All business logic is encapsulated in components and crews.

## How to Use the New Structure

### Running the Application

Use the new main entry point:
```bash
python app/main_new.py
```

The old `app/main.py` is preserved for reference but should not be used.

### Adding a New Agent

1. Create a new directory under `agents/`:
```
agents/
  your_agent/
    __init__.py
    agent.py
    schemas.py
```

2. In `agent.py`, define:
```python
def create_your_agent() -> Agent:
    """Create your agent."""
    return Agent(
        role='Your Role',
        goal='Your goal',
        backstory='Your backstory',
        verbose=Config.VERBOSE,
        allow_delegation=False
    )

def create_your_task(agent: Agent, **kwargs) -> Task:
    """Create task for your agent."""
    return Task(
        description="...",
        agent=agent,
        # ... other task config
    )
```

3. In `schemas.py`, define output schemas:
```python
class YourOutput(BaseModel):
    field1: str
    field2: int
```

4. In `__init__.py`, export public interface:
```python
from .agent import create_your_agent, create_your_task
from .schemas import YourOutput

__all__ = ['create_your_agent', 'create_your_task', 'YourOutput']
```

### Adding a New Crew

1. Create `crews/your_crew.py`:
```python
class YourCrew:
    def __init__(self, **kwargs):
        # Create agents
        self.agent1 = create_agent1()
        self.agent2 = create_agent2()
        
        # Create tasks
        self.task1 = create_task1(self.agent1, **kwargs)
        self.task2 = create_task2(self.agent2, **kwargs)
        
        # Create crew
        self.crew = Crew(
            agents=[self.agent1, self.agent2],
            tasks=[self.task1, self.task2],
            process=Process.sequential
        )
    
    def kickoff(self):
        return self.crew.kickoff()
```

2. Export from `crews/__init__.py`:
```python
from .your_crew import YourCrew
```

### Modifying an Agent

All changes are localized to the agent's directory:
- Change agent definition: Edit `agent.py`
- Change task logic: Edit `agent.py`
- Change output schema: Edit `schemas.py`
- Update exports: Edit `__init__.py`

No need to touch other agents or main.py!

## Migration Path

If you have existing code using the old structure:

1. **Keep old files temporarily** - Don't delete them yet
2. **Update imports** - Switch from old imports to new:
   ```python
   # Old
   from agents.agents import EducationalAgents
   from agents.tasks import EducationalTasks
   from agents.schemas import CurriculumProposal
   
   # New
   from agents.principal import create_principal_agent, create_topic_identification_task, CurriculumProposal
   ```
3. **Test thoroughly** - Make sure everything works
4. **Remove old files** - Once confident, delete old structure

## Benefits Recap

1. **Modularity**: Each agent is self-contained
2. **Maintainability**: Easy to find and modify code
3. **Scalability**: Add new agents without affecting existing ones
4. **Testability**: Test agents independently
5. **Clarity**: Code organization reflects system architecture
6. **Collaboration**: Multiple developers can work on different agents
7. **Reusability**: Agents can be reused in different crews

## Best Practices

1. **Keep agents focused**: One agent, one responsibility
2. **Make tasks configurable**: Use function parameters for dynamic input
3. **Define clear schemas**: Use Pydantic for structured outputs
4. **Document interfaces**: Add docstrings to all public functions
5. **Export cleanly**: Use `__init__.py` to define public API
6. **Test components**: Write tests for individual agents before integration
7. **Version schemas**: Add schema version field for future compatibility

## Questions?

This restructuring follows industry best practices for:
- Domain-Driven Design (DDD)
- Component-Based Architecture
- Separation of Concerns
- Clean Code principles

The result is a more professional, maintainable, and scalable codebase!
